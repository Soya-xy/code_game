import 'uno.css'

import 'vuetify/styles'

// import '@unocss/reset/tailwind.css'
import './styles/main.css'
