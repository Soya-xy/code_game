<script setup lang='ts'>
</script>

<template>
  <div>
    <v-carousel hide-delimiters height="241" :show-arrows="false">
      <v-carousel-item src="/img/tu.png" cover />
    </v-carousel>
  </div>
</template>
