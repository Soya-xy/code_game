<script setup lang='ts'>
</script>

<template>
  <iframe id="chat-widget" allow="clipboard-read; clipboard-write; autoplay; microphone *; camera *; display-capture *; picture-in-picture *; fullscreen *;" src="https://secure.livechatinc.com/customer/action/open_chat?license_id=16502796&amp;group=0&amp;embedded=1&amp;widget_version=3&amp;unique_groups=0" allowtransparency="true" name="chat-widget" title="LiveChat chat widget" scrolling="no" h-100vh w-full />
</template>
