<script setup lang="ts">
</script>

<template>
  <div>
    <Suspense>
      <main>
        <RouterView />
      </main>
    </Suspense>
    <TabbarTabbar />
  </div>
</template>
