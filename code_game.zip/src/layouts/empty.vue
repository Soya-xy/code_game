<template>
  <main>
    <RouterView />
  </main>
</template>
